package com.ch.List;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.ch.Dao.Dao;
import com.ch.Dto.Dto;

public class controllerList {
	public ArrayList<Dto> posts;
	public Dao dao = new Dao();
	static public int PER_PAGE=3;
	public int totalcount = 0;
	public int totalpage = 0;
	
	public int currentpage =0;
	
	
	int startpage=0; //첫시작번호
	int endpage=0;
	
	
	
	
	
	
	


	public controllerList(Dao dao, String currentpages) {
		super();
		this.dao = dao;
		this.currentpage = Integer.parseInt(currentpages);
		this.totalpage = totalpage();
		getList();
		
		startpage = ((currentpage-1)/PER_PAGE)*PER_PAGE+1;
		System.out.println(startpage);
		endpage = ((currentpage-1)/PER_PAGE+1)*PER_PAGE;
		System.out.println(endpage);
		
		if(endpage > totalpage) {
			endpage = totalpage;
		}
	}
	
	


	public void getList() {
		int startpage = (currentpage-1)*PER_PAGE;
		System.out.println(startpage);
		posts = dao.list(startpage);
	}

	public ArrayList<Dto> getPost(){
		return posts;
	}	
	
	public int totalpage() {
		int count = dao.WriteCount();
		
		int totalpage=0;
		
		if(count%PER_PAGE==0) {
			totalpage = count/PER_PAGE;
		}else {
			totalpage = count/PER_PAGE+1;
		}
		return totalpage;
	}
	
	
	
	public String pagin() {
		String html ="";
		
		if(currentpage>1) {
			html = html+String.format("<a href='/board/list?page=%s'>%s</a>&nbsp;", currentpage-1,"<-");
		}
		
		
		for(int i=startpage; i<=endpage; i++) {
			 html = html+String.format("<a href='/board/list?page=%s'>%s</a>&nbsp;", i,i);
		}
		
		if(endpage >0 && endpage<totalpage) {
			html = html+String.format("<a href='/board/list?page=%s'>%s</a>&nbsp;", currentpage+1,"->");
		}
		
		return html;
	}
	
	
	
	
	
	
}
