package com.ch.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import com.ch.service.*;
import com.ch.Dao.Dao;
import com.ch.Dto.Dto;
import com.ch.List.controllerList;

@WebServlet("/board/*")
public class controller extends HttpServlet {
	service ser;
	String nextPage;
    Dao dao;
	
    @Override
    public void init() throws ServletException{
    	dao = new Dao();
		ser = new service();
		
    }

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getPathInfo();
		System.out.println("action: " + "["+action+"]");
		
			switch(action) {
				case "/list":
					nextPage="/List/list.jsp";
					controllerList conlist = ser.list(request.getParameter("page"));
					request.setAttribute("conlist", conlist);
					break;
					
				case "/read":
					nextPage="/Read/read.jsp";
					Dto d = ser.read(request.getParameter("no"));
					request.setAttribute("readpost", d);
					break;
					
				case "/del":
					System.out.println("삭제실행");
					nextPage="/board/list";
					ser.del(request.getParameter("no"));
					break;
					
		}
			RequestDispatcher d = request.getRequestDispatcher(nextPage);
			d.forward(request, response);
	}

}
