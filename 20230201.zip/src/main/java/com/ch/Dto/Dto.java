package com.ch.Dto;

public class Dto {
	public int no;
	public String title;
	public String id;
	public String content;
	public String data;
	
	public Dto(int no, String title, String id, String content, String data) {
		super();
		this.no = no;
		this.title = title;
		this.id = id;
		this.content = content;
		this.data = data;
	}
	
	
	
	
	
	}
