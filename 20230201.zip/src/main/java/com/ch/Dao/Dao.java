package com.ch.Dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.ch.Dto.Dto;
import com.ch.List.controllerList;
import com.ch.db.*;

public class Dao {
	DB db = new DB();
	//list
			public ArrayList<Dto> list(int startpage) {
			db.mysql();
			db.connect();
				
				ArrayList<Dto> posts = new ArrayList<>();
				Dto post = null;
				
				String sql = String.format("select * from %s limit %s,%s", DB.board,startpage,controllerList.PER_PAGE);
				System.out.println("Listsql: "+"["+sql+"]");
				
				try {
					ResultSet rs = DB.st.executeQuery(sql);
					while(rs.next()) {
						post = new Dto(
								rs.getInt("B_NO"),
								rs.getString("B_TITLE"),
								rs.getString("B_ID"),
								rs.getString("B_TEXT"),
								rs.getString("B_DATETIME"));
						posts.add(post);
								
								
								
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				
				
				
				return posts;
				
			}
	
			///////////
			
			public int WriteCount() {
				db.mysql();
				db.connect();
				
				int writecount = 0;
				String  sql = String.format("select count(*) from %s" , db.board);
				try {
					ResultSet rs = db.st.executeQuery(sql);
					rs.next();
					
					 writecount = rs.getInt("count(*)");
					
					
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
				return writecount;
				
			
				
				
			}
			
			//////////////read//////////////
			
			public Dto read(int no) {
				db.mysql();
				db.connect();
				
				Dto post = null;
				
				String sql = String.format("select * from %s where B_NO = %s",db.board,no);
				System.out.println("Readsql: "+"["+sql+"]");
				try {
					ResultSet rs = db.st.executeQuery(sql);
					rs.next();
					post = new Dto(
							rs.getInt("B_NO"),
							rs.getString("B_TITLE"),
							rs.getString("B_ID"),
							rs.getString("B_TEXT"),
							rs.getString("B_DATETIME"));
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
				return post;
				
			}
			
			/////////////////Del///////////////////
			
			public void Del(int no) {
				db.mysql();
				db.connect();
				
				String sql = String.format("delete from %s where B_NO=%s" , db.board,no);
				System.out.println("delsql: "+"["+sql+"]");
				try {
					db.st.executeUpdate(sql);
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
	
	
	
	

}
