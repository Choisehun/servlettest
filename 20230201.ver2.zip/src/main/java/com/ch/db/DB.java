package com.ch.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DB {
	Connection con = null;
	static public Statement st = null;
	String id = "root";
	String pw = "0000";
	String database = "My_FBoard";
	String URl = "jdbc:mysql://localhost:3306/"+database;
	static public String board = "Board";
	
	
	
	public void mysql() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void connect() {
		mysql();
		
		try {
			con = DriverManager.getConnection(URl,id,pw);
			st = con.createStatement();
			
			System.out.println("DB연결");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
	}
	
	
}
