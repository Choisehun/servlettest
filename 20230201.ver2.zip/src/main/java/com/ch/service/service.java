package com.ch.service;

import com.ch.Dao.Dao;
import com.ch.Dto.Dto;
import com.ch.List.controllerList;

public class service {
	Dao dao = new Dao();
	
	


	public controllerList list(String currentpage) {
		if(currentpage == null || currentpage.equals("null")){
			currentpage = "1";
		}

		controllerList conlist = new controllerList(dao,currentpage);
		return conlist;
	}
	
	public Dto read(String no) {
		return dao.read(Integer.parseInt(no));
	}
	
	public void del(String no) {
		dao.Del(Integer.parseInt(no));
	}
	
	public void update(Dto updatedto,String no) {
		dao.update(updatedto,Integer.parseInt(no));
	}
	
	public void write(Dto d) {
		dao.write(d);
	}
	
	public void member(Dto memberDto) {
		dao.member(memberDto);
	}
	
	public void login(Dto loginDto) {
		dao.login(loginDto);
	}
	
	

}
