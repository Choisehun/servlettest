package com.ch.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import com.ch.service.*;
import com.ch.Dao.Dao;
import com.ch.Dto.Dto;
import com.ch.List.controllerList;

@WebServlet("/board/*")
public class controller extends HttpServlet {
	service ser;
	String nextPage;
    Dao dao;
	
    @Override
    public void init() throws ServletException{
    	dao = new Dao();
		ser = new service();
		
    }

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getPathInfo();
		System.out.println("action: " + "["+action+"]");
		
			switch(action) {
				case "/list":
					nextPage="/List/list.jsp";
					controllerList conlist = ser.list(request.getParameter("page"));
					request.setAttribute("conlist", conlist);
					break;
					
				case "/read":
					nextPage="/Read/read.jsp";
					Dto d = ser.read(request.getParameter("no"));
					request.setAttribute("readpost", d);
					break;
					
				case "/del":
					System.out.println("삭제실행");
					nextPage="/board/list";
					ser.del(request.getParameter("no"));
					break;
					  
				case "/update":
					System.out.println("수정페이지");
					nextPage="/Update/update.jsp";
					request.setAttribute("udpateNo", ser.read(request.getParameter("no")));
					break;
					
				case "/updateproc":
					System.out.println("수정실행");
					nextPage="/board/list";
					Dto updatedto = new Dto(
							Integer.parseInt(request.getParameter("no")),
							request.getParameter("title"),
							request.getParameter("content")
							);
					ser.update(updatedto,request.getParameter("no"));
					break;
					
				case "/write":
					System.out.println("글작성완료");
					nextPage="/board/list";
					Dto writeDto = new Dto(
							request.getParameter("title"),
							request.getParameter("id"),
							request.getParameter("content"),
							request.getParameter("data")

							);
					ser.write(writeDto);
					break;
				case "/member":
					System.out.println("회원가입완료");
					nextPage="/index.jsp";
					Dto memberDto = new Dto(
								request.getParameter("mid"),
								request.getParameter("pw")
							);
					ser.member(memberDto);
					request.setAttribute("memberDto", memberDto);
					break;
					
				case "/login":
					System.out.println("로그인완료");
					nextPage="/board/list";
					Dto loginDto = new Dto(
							request.getParameter("mid"),
							request.getParameter("pw")
						);
					ser.login(loginDto);
					
					
		}
			RequestDispatcher d = request.getRequestDispatcher(nextPage);
			d.forward(request, response);
	}

}
