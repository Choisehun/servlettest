package com.ch.Dto;

public class Dto {
	public int no;
	public String title;
	public String id;
	public String content;
	public String data;
	public String mid;
	public String pw;
	
	
	public Dto(int no, String title, String id, String content, String data) {
		super();
		this.no = no;
		this.title = title;
		this.id = id;
		this.content = content;
		this.data = data;
	}

	public Dto(int no, String title, String content) {
		super();
		this.no = no;
		this.title = title;
		this.content = content;
	}

	public Dto(String title, String id, String content, String data) {
		super();
		this.title = title;
		this.id = id;
		this.content = content;
		this.data = data;
	}

	public Dto(String mid, String pw) {
		super();
		this.mid = mid;
		this.pw = pw;
	}

	

	
	
	
	
	
	
	}
